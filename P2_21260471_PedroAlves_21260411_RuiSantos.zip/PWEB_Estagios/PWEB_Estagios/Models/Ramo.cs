﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PWEB_Estagios.Models
{
    public enum Ramo
    {
        DA = 1,
        RAD = 2,
        SI = 3,
        COMUM = 4
    }
}